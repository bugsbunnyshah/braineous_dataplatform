git status
git add *
git commit -m 'get_started'
git status